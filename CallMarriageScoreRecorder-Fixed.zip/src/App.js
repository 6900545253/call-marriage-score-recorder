
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const MAX_ROUNDS = 5;

const ScoreRecorder = () => {
  const [playerNames, setPlayerNames] = useState(['', '', '', '']);
  const [scores, setScores] = useState(Array(4).fill(0));
  const [rounds, setRounds] = useState([]);
  const [currentRound, setCurrentRound] = useState(1);
  const [inputs, setInputs] = useState(Array(4).fill({ call: '', won: '' }));
  const [winner, setWinner] = useState('');
  const [tieBreaker, setTieBreaker] = useState(false);

  const handleNameChange = (index, value) => {
    const newNames = [...playerNames];
    newNames[index] = value;
    setPlayerNames(newNames);
  };

  const handleInputChange = (index, field, value) => {
    const newInputs = [...inputs];
    newInputs[index] = { ...newInputs[index], [field]: value };
    setInputs(newInputs);
  };

  const calculateRound = () => {
    const newScores = [...scores];
    inputs.forEach((input, index) => {
      const call = parseInt(input.call);
      const won = parseInt(input.won);
      if (isNaN(call) || isNaN(won)) return;
      if (won < call) newScores[index] += -call;
      else newScores[index] += call + 0.1 * (won - call);
    });
    setScores(newScores);
    setRounds([...rounds, inputs]);
    setInputs(Array(4).fill({ call: '', won: '' }));
    const nextRound = currentRound + 1;
    if (nextRound > MAX_ROUNDS && !tieBreaker) {
      const maxScore = Math.max(...newScores);
      const topScorers = newScores.filter(s => s === maxScore);
      if (topScorers.length > 1) {
        setTieBreaker(true);
      } else {
        const winnerIndex = newScores.indexOf(maxScore);
        setWinner(playerNames[winnerIndex]);
      }
    }
    setCurrentRound(nextRound);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Call Marriage Score Recorder</h1>
      <p className="mb-6 text-sm text-gray-500">Built by Zubin</p>
      <div className="flex gap-4 mb-6">
        {playerNames.map((name, idx) => (
          <input
            key={idx}
            className="border p-2 rounded w-full"
            placeholder={`Player ${idx + 1} Name`}
            value={name}
            onChange={(e) => handleNameChange(idx, e.target.value)}
          />
        ))}
      </div>

      {winner ? (
        <div className="text-xl font-semibold text-green-600">Winner: {winner}!</div>
      ) : (
        <Card className="mb-6">
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-4">Round {currentRound}</h2>
            <div className="grid grid-cols-4 gap-4">
              {inputs.map((input, idx) => (
                <div key={idx} className="space-y-2">
                  <input
                    type="number"
                    className="border p-2 rounded w-full"
                    placeholder="Call"
                    value={input.call}
                    onChange={(e) => handleInputChange(idx, 'call', e.target.value)}
                  />
                  <input
                    type="number"
                    className="border p-2 rounded w-full"
                    placeholder="Won"
                    value={input.won}
                    onChange={(e) => handleInputChange(idx, 'won', e.target.value)}
                  />
                </div>
              ))}
            </div>
            <Button className="mt-4" onClick={calculateRound}>Submit Round</Button>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-4 gap-4">
        {scores.map((score, idx) => (
          <div key={idx} className="bg-gray-100 p-4 rounded shadow">
            <div className="font-bold">{playerNames[idx] || `Player ${idx + 1}`}</div>
            <div className="text-lg">Score: {score.toFixed(1)}</div>
          </div>
        ))}
      </div>

      <div className="fixed bottom-4 right-4 bg-black text-white p-2 rounded-full text-xl font-bold">Z</div>
    </div>
  );
};

export default ScoreRecorder;
