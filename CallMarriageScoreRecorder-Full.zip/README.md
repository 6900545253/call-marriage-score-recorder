# Call Marriage Score Recorder
A simple React app to record scores for the Call Marriage card game.